package chatroom;

public class AppChat {
    public static void main(String[] args){
        ChatSubPub chatSubPub = new ChatSubPub();
        chatSubPub.pub();

    }


}
